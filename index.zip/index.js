var Wherewolf = require('wherewolf');
var geojson = require('./geojson/500k.json')

exports.handler = function(event, context, callback) {
    var wolf = Wherewolf();
    wolf.add("districts",geojson);
    var boundary = new Promise((resolve,reject) => {
        var response = wolf.find([parseFloat(event.queryStringParameters.lon), parseFloat(event.queryStringParameters.lat)]);
        console.log(response)
        resolve(response);
    });

    return boundary.then((result) => {
        if(result.districts == null){
            return callback(null,'error: error')
        }
        return callback(null, 
                {
                    'statusCode': 200,
                    'headers': { 'Content-Type': 'application/json' },
                    'body': JSON.stringify(result)
                    
                }
            );
        
    });

};