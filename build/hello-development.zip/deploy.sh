node-lambda package
aws lambda update-function-code --function-name get_cd --zip-file fileb://build/hello-development.zip